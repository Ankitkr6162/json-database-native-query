package io.spring.json.database.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import io.spring.json.database.domain.User;

public interface UserRepository extends CrudRepository<User, Long> {

	@Query(value = "SELECT * FROM CUSTOM_USER WHERE id=9", nativeQuery = true)
	List<User> findAllUsingNativeQuery();

}
